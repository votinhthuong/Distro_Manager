<?php

    if (defined('LOADED') == false)
        exit;

    define('MYSQL_RESTORE_MANAGER_ACTION_DELETE_MULTI',   'delete_multi');
    define('MYSQL_RESTORE_MANAGER_ACTION_DOWNLOAD_MULTI', 'download_multi');

    define('MYSQL_RESTORE_RECORD_PARAMETER_FILE_URL', 'record_file');

?>